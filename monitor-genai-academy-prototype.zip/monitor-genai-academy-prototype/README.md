# Monitor — Gen AI Academy Prototype

This repository contains a simplified hackathon prototype of **Monitor**, created for the **Gen AI Academy APAC Edition** submission.

It demonstrates the core concept, user journey, data-intelligence workflow, and Google Cloud / AI architecture using sample data.

This is **not** the production Monitor platform. Production source code, private integrations, proprietary prompts, paid data sources, API keys, security controls, and commercial workflows are intentionally excluded.

Copyright © 2026 Ricky Sng / Blue River. All rights reserved.

---

## Problem statement

Regional decision-makers in Singapore and ASEAN face fragmented information across news, markets, disasters, geopolitics, infrastructure, and policy sources. Manual monitoring is slow, inconsistent, and hard to convert into a briefing. **Monitor** turns scattered regional signals into a focused dashboard, AI-assisted impact summary, risk ranking, and exportable brief so users can make faster, better-informed decisions.

## Prototype scope

This public repository is deliberately lightweight. It includes:

- A single-page landing page and dashboard mockup.
- Regional intelligence cards generated from sample JSON data.
- A simplified workflow: `ingest → clean → classify → score → summarize → brief`.
- A mock Gemini / Vertex AI-style summary panel.
- Exportable Markdown briefing output.
- Architecture and workflow diagrams.
- Sample-only data files.

It excludes:

- Real internal feeds.
- Paid APIs.
- Proprietary data sources.
- Production prompts.
- Cloudflare tokens, Google credentials, API keys, OAuth secrets, or private endpoints.
- Production Monitor code and commercial workflows.

## Challenge alignment

The submission answers the challenge: **Create a data intelligence tool people would actually use, and show how acceleration helps them make a faster or better decision.**

| Hackathon expectation | How this prototype addresses it |
|---|---|
| Clear real-world user and problem | Regional operators, analysts, founders, and decision-makers need faster situational awareness. |
| Specific decision workflow | Decide what events need attention, what impact they may have, and what should be briefed. |
| Data pipeline | Sample event ingestion, normalization, classification, scoring, and summarization. |
| Useful output | Dashboard, risk scores, priority cards, AI brief, recommended actions, and exportable report. |
| Acceleration evidence | Simulated comparison of manual scanning versus AI-assisted briefing workflow. |
| Google Cloud usage | Intended production architecture uses Cloud Storage, BigQuery, Vertex AI Gemini, Looker, and Cloud Run / Cloud Functions. |

## How the prototype works

```mermaid
flowchart LR
  A[Sample regional event data] --> B[Ingest]
  B --> C[Clean and normalize]
  C --> D[Classify by theme and geography]
  D --> E[Score impact and urgency]
  E --> F[Gemini-style AI summary]
  F --> G[Dashboard cards]
  F --> H[Export briefing]
```

## Intended production architecture

```mermaid
flowchart LR
  A[Public / licensed regional data feeds] --> B[Cloud Storage raw landing]
  B --> C[BigQuery curated tables]
  C --> D[Vertex AI Gemini summarization and reasoning]
  D --> E[Risk scoring and briefing API on Cloud Run]
  E --> F[Monitor dashboard]
  C --> G[Looker analytics layer]
  E --> H[Exportable decision brief]
```

## Repository structure

```text
monitor-genai-academy-prototype/
├── index.html
├── styles.css
├── app.js
├── data/
│   ├── sample_events.json
│   └── sample_metrics.csv
├── docs/
│   ├── architecture.md
│   ├── architecture.svg
│   ├── workflow.svg
│   └── security-and-submission-notes.md
├── src/
│   ├── vertex-ai-adapter.example.js
│   └── bigquery-schema.sql
├── SUBMISSION_ANSWERS.md
├── NOTICE.md
├── _headers
├── .gitignore
├── package.json
└── wrangler.toml.example
```

## Run locally

Because this is a static prototype, any local static server works.

```bash
python -m http.server 8080
```

Then open:

```text
http://localhost:8080
```

## Deploy publicly

Recommended public deployment options:

1. **Cloudflare Pages**
   - Framework preset: None
   - Build command: leave blank
   - Output directory: `/`

2. **GitHub Pages**
   - Upload this repository.
   - Enable Pages from the main branch root.

## Suggested GitHub repo name

```text
monitor-genai-academy-prototype
```

## Suggested submission links

- Working Prototype Deployed Link: `https://monitor.blueriver.cc/demo` or your public Cloudflare Pages URL.
- GitHub Repository Link: your new public stripped prototype repo.
- Demo Video Link: a short walkthrough under 3 minutes.

## IP and usage notice

This public prototype is shared for hackathon evaluation only. No open-source license is granted. All rights are reserved by Ricky Sng / Blue River.
