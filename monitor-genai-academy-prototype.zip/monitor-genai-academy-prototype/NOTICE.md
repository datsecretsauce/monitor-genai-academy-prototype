# Notice

Copyright © 2026 Ricky Sng / Blue River. All rights reserved.

This repository is a simplified public hackathon prototype. It is not licensed as open source. Viewing the code does not grant permission to copy, modify, redistribute, commercialize, or reuse the production concept, architecture, prompts, branding, or implementation beyond hackathon evaluation.

Production source code, private integrations, proprietary prompts, paid data sources, API keys, security controls, and commercial workflows are intentionally excluded.
