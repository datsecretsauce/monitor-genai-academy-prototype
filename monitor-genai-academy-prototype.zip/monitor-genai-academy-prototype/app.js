const state = {
  rawEvents: [],
  processedEvents: [],
  activeCategory: "all",
  activeRegion: "all",
  latestBrief: ""
};

const categoryColours = {
  weather: "high",
  cyber: "high",
  maritime: "medium",
  market: "medium",
  infrastructure: "medium",
  logistics: "medium",
  policy: "low",
  financial: "low"
};

const fallbackEvents = [
  {
    id: "fallback-001",
    title: "Sample regional weather watch",
    region: "Singapore",
    countryCode: "SG",
    category: "weather",
    severity: "medium",
    confidence: 0.75,
    lat: 1.35,
    lon: 103.82,
    sourceType: "fallback demo data",
    summary: "Local fallback data is shown because sample_events.json could not be loaded.",
    decisionNeed: "Check the repository data file path.",
    recommendedAction: "Run from a static server instead of opening the file directly.",
    timestamp: new Date().toISOString()
  }
];

async function init() {
  state.rawEvents = await loadEvents();
  populateRegionFilter(state.rawEvents);
  setupCategoryFilters(state.rawEvents);
  runPipeline({ animate: false });
  bindEvents();
}

async function loadEvents() {
  try {
    const response = await fetch("data/sample_events.json", { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (error) {
    console.warn("Using fallback demo data:", error);
    return fallbackEvents;
  }
}

function bindEvents() {
  document.getElementById("runPipeline")?.addEventListener("click", () => runPipeline({ animate: true }));
  document.getElementById("runPipelineTop")?.addEventListener("click", () => runPipeline({ animate: true }));
  document.getElementById("exportBrief")?.addEventListener("click", exportBrief);
  document.getElementById("regionFilter")?.addEventListener("change", (event) => {
    state.activeRegion = event.target.value;
    render();
  });
}

function populateRegionFilter(events) {
  const select = document.getElementById("regionFilter");
  if (!select) return;
  const regions = [...new Set(events.map(event => event.region))].sort();
  for (const region of regions) {
    const option = document.createElement("option");
    option.value = region;
    option.textContent = region;
    select.appendChild(option);
  }
}

function setupCategoryFilters(events) {
  const container = document.getElementById("categoryFilters");
  if (!container) return;
  const categories = ["all", ...new Set(events.map(event => event.category))].sort((a, b) => a === "all" ? -1 : b === "all" ? 1 : a.localeCompare(b));
  container.innerHTML = "";
  for (const category of categories) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = category === "all" ? "All" : titleCase(category);
    button.dataset.category = category;
    button.className = category === state.activeCategory ? "active" : "";
    button.addEventListener("click", () => {
      state.activeCategory = category;
      setupCategoryFilters(state.rawEvents);
      render();
    });
    container.appendChild(button);
  }
}

function runPipeline({ animate }) {
  const ingested = ingest(state.rawEvents);
  const cleaned = clean(ingested);
  const classified = classify(cleaned);
  const scored = score(classified);
  state.processedEvents = scored.sort((a, b) => b.impactScore - a.impactScore);
  state.latestBrief = summarizeForDecisionBrief(state.processedEvents);
  render();
  if (animate) animateWorkflow();
}

function ingest(events) {
  return events.map(event => ({ ...event, ingestedAt: new Date().toISOString() }));
}

function clean(events) {
  return events.map(event => ({
    ...event,
    region: String(event.region || "Unknown").trim(),
    category: String(event.category || "general").trim().toLowerCase(),
    severity: String(event.severity || "low").trim().toLowerCase(),
    confidence: Number(event.confidence || 0.5),
    timestamp: event.timestamp || new Date().toISOString()
  }));
}

function classify(events) {
  return events.map(event => ({
    ...event,
    decisionTheme: classifyTheme(event),
    timeHorizon: event.severity === "high" ? "Immediate" : event.severity === "medium" ? "Next 24-48h" : "Monitor"
  }));
}

function classifyTheme(event) {
  const category = event.category;
  if (["weather", "cyber", "maritime"].includes(category)) return "Operational resilience";
  if (["market", "financial", "policy"].includes(category)) return "Management briefing";
  if (["infrastructure", "logistics"].includes(category)) return "Continuity planning";
  return "General monitoring";
}

function score(events) {
  const severityWeight = { low: 35, medium: 62, high: 84 };
  return events.map(event => {
    const base = severityWeight[event.severity] || 35;
    const confidenceBoost = Math.round((event.confidence || 0.5) * 12);
    const singaporeRelevance = event.countryCode === "SG" ? 8 : 0;
    const impactScore = Math.min(99, base + confidenceBoost + singaporeRelevance);
    return {
      ...event,
      impactScore,
      priority: impactScore >= 88 ? "High" : impactScore >= 70 ? "Medium" : "Watch"
    };
  });
}

function summarizeForDecisionBrief(events) {
  const top = events.slice(0, 3);
  const highCount = events.filter(event => event.priority === "High").length;
  const regions = [...new Set(events.map(event => event.region))].join(", ");
  const actions = top.map((event, index) => `${index + 1}. ${event.title}: ${event.recommendedAction}`).join("\n");

  return [
    "Situation",
    `${events.length} sample regional signals were ingested, cleaned, classified, and scored across ${regions}. ${highCount} item(s) are high priority in this demo run.`,
    "",
    "Impact",
    `The most important themes are ${[...new Set(top.map(event => event.decisionTheme))].join(", ")}. The dashboard prioritizes items by severity, confidence, and Singapore/ASEAN relevance.`,
    "",
    "Recommended next steps",
    actions,
    "",
    "Acceleration note",
    "A manual scan is estimated at 45 minutes. This prototype compresses the workflow into an estimated 7-minute dashboard-to-brief process using structured scoring and Gemini-style summarization."
  ].join("\n");
}

function render() {
  const events = getFilteredEvents();
  renderCards(events);
  renderMap(events);
  renderAiSummary(events);
  renderKpis(events);
}

function getFilteredEvents() {
  return state.processedEvents.filter(event => {
    const categoryMatch = state.activeCategory === "all" || event.category === state.activeCategory;
    const regionMatch = state.activeRegion === "all" || event.region === state.activeRegion;
    return categoryMatch && regionMatch;
  });
}

function renderCards(events) {
  const grid = document.getElementById("cardsGrid");
  if (!grid) return;
  grid.innerHTML = "";
  if (!events.length) {
    grid.innerHTML = `<p class="empty">No sample signals match this filter.</p>`;
    return;
  }
  for (const event of events) {
    const article = document.createElement("article");
    article.className = "signal-card";
    article.innerHTML = `
      <div class="meta">
        <span class="category">${escapeHtml(event.category)}</span>
        <span class="score">${event.impactScore}</span>
      </div>
      <h4>${escapeHtml(event.title)}</h4>
      <p>${escapeHtml(event.summary)}</p>
      <div class="tags">
        <span>${escapeHtml(event.region)}</span>
        <span>${escapeHtml(event.priority)} priority</span>
        <span>${escapeHtml(event.timeHorizon)}</span>
      </div>
    `;
    grid.appendChild(article);
  }
}

function renderMap(events) {
  const map = document.getElementById("miniMap");
  if (!map) return;
  map.innerHTML = "";
  for (const event of events) {
    const marker = document.createElement("span");
    marker.className = `map-marker ${categoryColours[event.category] || event.severity}`;
    const { x, y } = projectToMiniMap(event.lat, event.lon);
    marker.style.left = `${x}%`;
    marker.style.top = `${y}%`;
    marker.title = `${event.region}: ${event.title}`;
    map.appendChild(marker);
  }
}

function renderAiSummary(events) {
  const summary = document.getElementById("aiSummary");
  if (!summary) return;
  const brief = events.length === state.processedEvents.length
    ? state.latestBrief
    : summarizeForDecisionBrief(events);
  summary.textContent = brief;
}

function renderKpis(events) {
  const averageConfidence = events.length
    ? Math.round(events.reduce((sum, event) => sum + event.confidence, 0) / events.length * 100)
    : 0;
  const topRisk = state.processedEvents[0]?.impactScore || "--";
  document.getElementById("heroEvents").textContent = state.processedEvents.length;
  document.getElementById("heroTopRisk").textContent = topRisk;
  document.getElementById("confidenceKpi").textContent = `${averageConfidence || "--"}%`;
}

function projectToMiniMap(lat, lon) {
  // Simple bounding-box projection for ASEAN demo view.
  const minLat = -10, maxLat = 25, minLon = 95, maxLon = 126;
  const x = ((lon - minLon) / (maxLon - minLon)) * 100;
  const y = (1 - ((lat - minLat) / (maxLat - minLat))) * 100;
  return {
    x: clamp(x, 5, 95),
    y: clamp(y, 7, 93)
  };
}

function exportBrief() {
  const events = getFilteredEvents();
  const timestamp = new Date().toISOString();
  const lines = [
    "# Monitor Decision Brief — Demo Prototype",
    "",
    `Generated: ${timestamp}`,
    "Source: sample demo data only",
    "AI mode: Gemini / Vertex AI-style local mock summary",
    "",
    "## Executive summary",
    summarizeForDecisionBrief(events),
    "",
    "## Prioritized signals",
    ...events.map(event => `- **${event.priority} | ${event.impactScore}** — ${event.title} (${event.region}, ${titleCase(event.category)}). Action: ${event.recommendedAction}`),
    "",
    "## Disclaimer",
    "This is a public hackathon prototype using sample data. Validate all material decisions against authoritative sources."
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `monitor-demo-brief-${timestamp.slice(0, 10)}.md`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function animateWorkflow() {
  const cards = [...document.querySelectorAll("#workflowGrid article")];
  cards.forEach(card => card.classList.remove("active"));
  cards.forEach((card, index) => {
    setTimeout(() => {
      cards.forEach(item => item.classList.remove("active"));
      card.classList.add("active");
    }, index * 280);
  });
  setTimeout(() => cards.forEach(card => card.classList.remove("active")), cards.length * 280 + 800);
}

function titleCase(value) {
  return String(value).replace(/[-_]/g, " ").replace(/\b\w/g, letter => letter.toUpperCase());
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

init();
