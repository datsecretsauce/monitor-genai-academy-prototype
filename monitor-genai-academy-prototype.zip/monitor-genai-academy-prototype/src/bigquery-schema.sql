-- Monitor prototype BigQuery schema sketch.
-- No production data is included.

CREATE TABLE IF NOT EXISTS `PROJECT_ID.monitor_demo.regional_events` (
  id STRING NOT NULL,
  title STRING,
  region STRING,
  countryCode STRING,
  category STRING,
  severity STRING,
  confidence FLOAT64,
  lat FLOAT64,
  lon FLOAT64,
  sourceType STRING,
  summary STRING,
  decisionNeed STRING,
  recommendedAction STRING,
  eventTimestamp TIMESTAMP,
  ingestedAt TIMESTAMP
);

CREATE OR REPLACE VIEW `PROJECT_ID.monitor_demo.event_priority_view` AS
SELECT
  id,
  title,
  region,
  category,
  severity,
  confidence,
  CASE
    WHEN severity = 'high' THEN 84
    WHEN severity = 'medium' THEN 62
    ELSE 35
  END + CAST(ROUND(confidence * 12) AS INT64) AS demoImpactScore,
  eventTimestamp
FROM `PROJECT_ID.monitor_demo.regional_events`;
