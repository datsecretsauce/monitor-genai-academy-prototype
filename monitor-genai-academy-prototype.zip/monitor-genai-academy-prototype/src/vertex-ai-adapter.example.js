/**
 * Monitor — Vertex AI / Gemini adapter sketch
 *
 * This file is intentionally an example only.
 * It does NOT contain API keys, OAuth secrets, service-account JSON, or endpoints.
 *
 * Production idea:
 * - Run this server-side on Google Cloud Run or Cloud Functions.
 * - Use Application Default Credentials instead of hard-coded keys.
 * - Store raw data in Cloud Storage and curated event tables in BigQuery.
 * - Send only the minimum necessary event fields to Vertex AI Gemini.
 */

export function buildGeminiBriefingPrompt(events) {
  const safeEvents = events.map(event => ({
    title: event.title,
    region: event.region,
    category: event.category,
    severity: event.severity,
    confidence: event.confidence,
    summary: event.summary,
    decisionNeed: event.decisionNeed,
    recommendedAction: event.recommendedAction
  }));

  return `
You are assisting a regional decision-maker.
Use only the supplied event data. Do not invent facts.

Return a concise briefing with:
1. Situation
2. Impact
3. Top priorities
4. Recommended next steps
5. Confidence and limitations

EVENTS:
${JSON.stringify(safeEvents, null, 2)}
`.trim();
}

export async function summarizeWithGeminiExample(events) {
  const prompt = buildGeminiBriefingPrompt(events);

  // Production sketch only:
  // const { VertexAI } = await import("@google-cloud/vertexai");
  // const vertex = new VertexAI({ project: process.env.GOOGLE_CLOUD_PROJECT, location: "asia-southeast1" });
  // const model = vertex.getGenerativeModel({ model: "gemini-1.5-pro" });
  // const result = await model.generateContent(prompt);
  // return result.response.candidates[0].content.parts[0].text;

  return {
    mode: "example-only",
    prompt,
    summary: "This public prototype uses local deterministic summarization. Production can call Gemini through Vertex AI from a server-side runtime."
  };
}
