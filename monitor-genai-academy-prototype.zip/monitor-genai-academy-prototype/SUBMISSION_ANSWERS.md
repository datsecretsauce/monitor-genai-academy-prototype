# Submission answers

## Participant Name

Ricky Sng

## Problem Statement

Create a data intelligence tool people would actually use, and show how acceleration helps them make a faster or better decision.

## Brief about the idea

Monitor is a regional intelligence dashboard for Singapore and ASEAN decision-makers. It helps users turn fragmented signals across weather, cyber, markets, logistics, policy, infrastructure and maritime operations into a prioritized dashboard and AI-assisted briefing.

The prototype uses sample data to demonstrate the workflow: ingest regional event data, clean and normalize it, classify each event, score its likely impact, generate a Gemini / Vertex AI-style summary, and export a concise decision brief.

## Real-world problem and impact

Regional operators and decision-makers often scan many sources manually before producing a briefing. This is slow and inconsistent, especially when events are spread across different countries, sectors and data formats.

Monitor reduces the time-to-insight by converting signals into decision-ready outputs: risk cards, impact scores, top priorities, recommended next steps and an exportable brief.

## Core architecture / workflow

1. Ingest sample regional intelligence events from JSON/CSV.
2. Clean and normalize event data.
3. Classify events by category and decision theme.
4. Score each event by severity, confidence and regional relevance.
5. Generate a Gemini / Vertex AI-style decision summary.
6. Export the brief for management or operational use.

## USP

Monitor is designed as a practical regional decision-intelligence cockpit rather than a generic news dashboard. It links regional signals to a specific decision workflow: what happened, why it matters, how urgent it is, and what the user should do next.

## Features

- Landing page and prototype dashboard
- Sample regional intelligence data
- Regional map mockup
- Intelligence cards
- Impact scoring
- Gemini / Vertex AI-style AI summary panel
- Export briefing button
- Architecture documentation
- Security-safe public repository with no secrets

## Google Cloud technologies used / intended

- Cloud Storage: raw data landing zone for event files and feeds
- BigQuery: clean and curated analytics layer
- Vertex AI Gemini: summarization and decision brief generation
- Cloud Run / Cloud Functions: backend API for scoring and briefing workflows
- Looker: management dashboards and reporting

## Acceleration evidence

The prototype demonstrates a manual baseline of approximately 45 minutes to scan multiple sources and prepare a first brief, compared with an AI-assisted workflow of approximately 7 minutes from dashboard triage to briefing export. This is a prototype estimate used to show the acceleration concept.
