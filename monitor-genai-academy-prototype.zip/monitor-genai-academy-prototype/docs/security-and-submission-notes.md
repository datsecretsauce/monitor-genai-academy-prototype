# Security and submission notes

## Public repository strategy

Use this stripped repository for the hackathon public GitHub link. Keep the production Monitor repository private.

## What was intentionally removed

- Real RSS / API connectors
- Paid data-provider endpoints
- Google OAuth settings
- Cloudflare secrets
- Worker AI bindings
- Stripe or billing logic
- Internal admin logic
- Production prompts and scoring rules
- Proprietary source lists

## Submission copy

**Working prototype deployed link**

```text
https://monitor.blueriver.cc/demo
```

or your Cloudflare Pages URL.

**GitHub repository link**

```text
https://github.com/YOUR-USERNAME/monitor-genai-academy-prototype
```

**Brief description**

```text
Monitor is a regional intelligence dashboard that helps decision-makers turn fragmented signals from news, markets, weather, disasters, policy, cyber, logistics and infrastructure sources into a faster, AI-assisted briefing. The prototype ingests sample regional events, classifies them by theme and geography, applies transparent impact scoring, and uses a Gemini / Vertex AI-style workflow to generate decision-ready summaries, alerts and exportable briefings. This reduces time-to-insight from manual scanning across multiple sources to a focused dashboard and briefing workflow.
```

## Before making the repo public

Check that these are not present:

- `.env`
- API keys
- `GOOGLE_CLIENT_SECRET`
- Cloudflare API tokens
- Stripe keys
- Private endpoints
- Internal emails or access lists
- Production code copied from Monitor
- Any real user data
