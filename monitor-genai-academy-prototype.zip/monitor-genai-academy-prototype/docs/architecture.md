# Architecture notes

## Public prototype architecture

The public repository is a static, sample-data prototype:

```mermaid
flowchart LR
  A[Sample JSON / CSV] --> B[Browser JavaScript pipeline]
  B --> C[Classification]
  C --> D[Impact scoring]
  D --> E[Gemini-style local summary]
  E --> F[Dashboard cards]
  E --> G[Markdown briefing export]
```

This avoids exposing production secrets, private connectors, paid feeds, or internal APIs.

## Intended production Google Cloud architecture

```mermaid
flowchart LR
  A[Public and licensed signal feeds] --> B[Cloud Storage raw landing]
  B --> C[Dataflow / Cloud Run ingestion]
  C --> D[BigQuery curated intelligence tables]
  D --> E[Vertex AI Gemini prompt orchestration]
  E --> F[Cloud Run briefing API]
  F --> G[Monitor web dashboard]
  D --> H[Looker dashboards]
  F --> I[Exportable briefing pack]
```

## Why this stack

- **Cloud Storage**: simple landing zone for raw event files, CSVs, JSON, and batch uploads.
- **BigQuery**: scalable analytics store for event history, scoring, reporting, and trend analysis.
- **Vertex AI Gemini**: enterprise-grade summarization, reasoning, and briefing generation.
- **Cloud Run / Cloud Functions**: lightweight API surface for summarization, scoring, and exports.
- **Looker**: management dashboards and governance reporting.

## Data model

Core event fields:

- `id`
- `title`
- `region`
- `countryCode`
- `category`
- `severity`
- `confidence`
- `lat`
- `lon`
- `sourceType`
- `summary`
- `decisionNeed`
- `recommendedAction`
- `timestamp`

## Safety boundaries

The public prototype is designed to be safely shared with judges:

- Uses synthetic sample data only.
- Does not include API keys.
- Does not include OAuth flows.
- Does not include paid data feeds.
- Does not include proprietary prompts.
- Does not include production Monitor source code.
